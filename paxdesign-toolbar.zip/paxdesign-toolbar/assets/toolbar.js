/* PaxDesign Toolbar — v1.0.0 */
(function () {
  'use strict';

  /* ── SVG icons ── */
  var IC = {
    trust:      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>',
    create:     '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"/></svg>',
    personas:   '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="3.5"/><path d="M5 20c0-3.5 3.1-6 7-6s7 2.5 7 6"/></svg>',
    automation: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><path d="M17.5 14v6M14.5 17h6"/></svg>',
    osint:      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="6.5"/><path d="M20 20l-3.5-3.5"/></svg>',
    connectors: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>',
    builder:    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/></svg>',
    pipeline:   '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><circle cx="5" cy="12" r="2"/><circle cx="19" cy="5" r="2"/><circle cx="19" cy="19" r="2"/><path d="M7 12h4l4-5M7 12l4 1 4 4"/></svg>',
    x:          '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>'
  };

  /* ── service content ── */
  var SVC = {
    create: {
      title: 'Create', sub: 'Custom digital product development',
      desc: 'From concept to deployment — web apps, automation tools, dashboards, and AI-powered systems built to your exact workflow.',
      features: ['Full-stack web application development', 'Custom admin panels and dashboards', 'API design and backend architecture', 'Database design and optimisation', 'Deployment and DevOps setup'],
      cta: 'Start a project'
    },
    personas: {
      title: 'AI Personas', sub: 'Custom AI agents with defined identity',
      desc: 'Branded AI assistants with specific personalities, knowledge bases, and communication styles — for customer service, sales, or internal operations.',
      features: ['Custom personality and tone configuration', 'Domain-specific knowledge base integration', 'Multi-channel deployment (web, Telegram, WhatsApp)', 'Conversation memory and context handling', 'Analytics and conversation monitoring'],
      cta: 'Book a consultation'
    },
    automation: {
      title: 'Browser Automation', sub: 'End-to-end web workflow automation',
      desc: 'Automate repetitive browser-based tasks — data collection, form processing, monitoring, and multi-step workflows built on Playwright and Puppeteer.',
      features: ['Web scraping and structured data extraction', 'Form automation and submission pipelines', 'Scheduled monitoring and alerting', 'Screenshot and PDF generation at scale', 'Login-protected site automation'],
      cta: 'Request this service'
    },
    osint: {
      title: 'OSINT Agents', sub: 'Automated open-source intelligence',
      desc: 'Structured intelligence gathering from public sources — for research, due diligence, brand monitoring, and threat awareness.',
      features: ['Domain and IP reputation analysis', 'Social media and public record monitoring', 'Entity relationship mapping', 'Automated reporting and alerting', 'Custom data source integration'],
      cta: 'Book a consultation'
    },
    connectors: {
      title: 'Connectors', sub: 'API integrations and data bridges',
      desc: 'The integrations your stack is missing — connecting CRMs, databases, SaaS platforms, and custom systems so your data flows where it needs to go.',
      features: ['REST and GraphQL API integration', 'Webhook design and event pipelines', 'CRM and ERP data synchronisation', 'Real-time data streaming', 'Legacy system modernisation bridges'],
      cta: 'Start a project'
    },
    builder: {
      title: 'AI Builder', sub: 'Low-code AI system construction',
      desc: 'Custom AI workflows, model integrations, and intelligent automation — designed and deployed without requiring your team to maintain complex code.',
      features: ['LLM workflow design and orchestration', 'Prompt engineering and optimisation', 'RAG system design and deployment', 'Model fine-tuning consultation', 'AI system monitoring and evaluation'],
      cta: 'Request this service'
    },
    pipeline: {
      title: 'Agent Pipeline', sub: 'Multi-agent orchestration systems',
      desc: 'Specialised AI agents that collaborate on complex tasks — research, analysis, generation, and decision pipelines built for your specific use case.',
      features: ['Multi-agent task decomposition design', 'Autonomous research and synthesis pipelines', 'Human-in-the-loop workflow integration', 'Agent monitoring and failure handling', 'Custom tool and API integration for agents'],
      cta: 'Book a consultation'
    }
  };

  /* ── DOM refs ── */
  var backdrop = document.getElementById('pdx-backdrop');
  var panel    = document.getElementById('pdx-panel');
  var inner    = document.getElementById('pdx-inner');
  var current  = null;

  /* contact URL injected by WordPress via wp_localize_script */
  var CONTACT = (typeof PDX !== 'undefined' && PDX.contact) ? PDX.contact : '#contact';

  /* ── open / close ── */
  function open(key) {
    /* toggle: clicking active icon closes panel */
    if (current === key) { close(); return; }

    /* mark active button */
    var btns = document.querySelectorAll('.pdx-ic');
    for (var i = 0; i < btns.length; i++) btns[i].classList.remove('pdx-active');
    var active = document.querySelector('[data-panel="' + key + '"]');
    if (active) active.classList.add('pdx-active');

    inner.innerHTML = key === 'trust' ? trustHTML() : svcHTML(key);
    panel.classList.add('on');
    backdrop.classList.add('on');
    document.body.style.overflow = 'hidden';
    current = key;

    if (key === 'trust') {
      var inp = document.getElementById('pdx-ti');
      if (inp) setTimeout(function () { inp.focus(); }, 230);
    }
  }

  function close() {
    panel.classList.remove('on');
    backdrop.classList.remove('on');
    document.body.style.overflow = '';
    var btns = document.querySelectorAll('.pdx-ic');
    for (var i = 0; i < btns.length; i++) btns[i].classList.remove('pdx-active');
    current = null;
  }

  /* ── header helper ── */
  function header(key, title, sub) {
    return '<div class="ph">'
      + '<div class="ph-left"><div class="ph-icon">' + IC[key] + '</div>'
      + '<div><h2>' + esc(title) + '</h2><p>' + esc(sub) + '</p></div></div>'
      + '<button class="ph-close" id="pdx-close" type="button" aria-label="Close">' + IC.x + '</button>'
      + '</div>';
  }

  /* ── service panel ── */
  function svcHTML(key) {
    var s = SVC[key];
    if (!s) return '';
    var items = s.features.map(function (f) { return '<li>' + esc(f) + '</li>'; }).join('');
    return header(key, s.title, s.sub)
      + '<p class="pb">' + esc(s.desc) + '</p>'
      + '<ul class="pfl">' + items + '</ul>'
      + '<div class="pcta">'
      + '<a href="' + CONTACT + '" class="p">' + esc(s.cta) + '</a>'
      + '<a href="' + CONTACT + '" class="g">Learn more</a>'
      + '</div>';
  }

  /* ── trust panel ── */
  function trustHTML() {
    return header('trust', 'Trust Check', 'Reputation \u00b7 SSL \u00b7 Domain age \u00b7 Risk score')
      + '<div class="ti-row">'
      + '<input class="ti" id="pdx-ti" type="text" placeholder="domain.com or https://\u2026" autocomplete="off" spellcheck="false"/>'
      + '<button class="tsb" id="pdx-scan" type="button">Scan</button>'
      + '</div>'
      + '<div id="pdx-tout"></div>';
  }

  /* ── trust checker ── */
  function parseDomain(raw) {
    var s = raw.trim();
    if (!s) return null;
    if (!/^https?:\/\//i.test(s)) s = 'https://' + s;
    try { var u = new URL(s); return { href: s, host: u.hostname }; }
    catch (e) { return null; }
  }

  function scan() {
    var raw    = document.getElementById('pdx-ti').value;
    var out    = document.getElementById('pdx-tout');
    var btn    = document.getElementById('pdx-scan');
    var parsed = parseDomain(raw);

    if (!parsed) {
      out.innerHTML = '<div class="tr-err">Enter a valid domain or URL.</div>';
      return;
    }

    btn.disabled = true;
    btn.textContent = 'Scanning\u2026';
    out.innerHTML = '<div class="tsp"><div class="tsp-ring"></div>Checking ' + esc(parsed.host) + '\u2026</div>';

    Promise.all([
      apiRDAP(parsed.host),
      apiSSL(parsed.host),
      apiGSB(parsed.href)
    ]).then(function (res) {
      out.innerHTML = buildResult(parsed.host, parsed.href, res[0], res[1], res[2]);
    }).catch(function () {
      out.innerHTML = '<div class="tr-err">Scan failed. Check your connection and try again.</div>';
    }).then(function () {
      btn.disabled = false;
      btn.textContent = 'Scan';
    });
  }

  /* public APIs — zero configuration required */
  function apiRDAP(domain) {
    return fetch('https://rdap.org/domain/' + encodeURIComponent(domain))
      .then(function (r) { return r.ok ? r.json() : null; })
      .catch(function () { return null; });
  }

  function apiSSL(domain) {
    return fetch('https://api.ssllabs.com/api/v3/analyze?host=' + encodeURIComponent(domain) + '&fromCache=on&maxAge=24&all=done')
      .then(function (r) { return r.ok ? r.json() : null; })
      .catch(function () { return null; });
  }

  function apiGSB(href) {
    return fetch('https://transparencyreport.google.com/transparencyreport/api/v3/safebrowsing/status?site=' + encodeURIComponent(href))
      .then(function (r) { return r.ok ? r.text() : null; })
      .catch(function () { return null; });
  }

  /* ── build result HTML ── */
  function buildResult(domain, href, rdap, ssl, gsb) {
    var score = 100;
    var good = [], warn = [], bad = [];

    /* HTTPS */
    var isHttps = /^https:/i.test(href);
    if (isHttps) { good.push('HTTPS'); }
    else { bad.push('No HTTPS'); score -= 20; }

    /* RDAP */
    var regDate = null, registrar = null, domainAge = null;
    if (rdap) {
      var ents = rdap.entities || [];
      outer: for (var i = 0; i < ents.length; i++) {
        var vcard = ents[i].vcardArray && ents[i].vcardArray[1];
        if (vcard) {
          for (var j = 0; j < vcard.length; j++) {
            if (vcard[j][0] === 'fn') { registrar = vcard[j][3]; break outer; }
          }
        }
      }
      var evts = rdap.events || [];
      for (var k = 0; k < evts.length; k++) {
        if (evts[k].eventAction === 'registration') {
          regDate = new Date(evts[k].eventDate);
          domainAge = Math.floor((Date.now() - regDate.getTime()) / 86400000);
          break;
        }
      }
      if (domainAge !== null) {
        if (domainAge < 30)       { bad.push('Domain < 30 days');   score -= 30; }
        else if (domainAge < 180) { warn.push('Domain < 6 months'); score -= 12; }
        else good.push('Domain ' + (domainAge < 365 ? domainAge + 'd' : Math.floor(domainAge / 365) + 'y') + ' old');
      }
    }

    /* SSL Labs */
    var sslGrade = null;
    if (ssl && ssl.endpoints && ssl.endpoints[0]) {
      sslGrade = ssl.endpoints[0].grade || null;
      if (sslGrade) {
        var g0 = sslGrade.charAt(0);
        if (g0 === 'A')      good.push('SSL ' + sslGrade);
        else if (g0 === 'B') { warn.push('SSL ' + sslGrade); score -= 8; }
        else                 { bad.push('SSL ' + sslGrade);  score -= 20; }
      }
    }

    /* Google Safe Browsing transparency */
    if (gsb) {
      try {
        var clean = gsb.replace(/^\)\]\}'\n/, '');
        var parsed = JSON.parse(clean);
        var threat = parsed && parsed[0] && parsed[0][1] && parsed[0][1][0];
        if (threat && threat !== 0) { bad.push('Google flagged'); score -= 40; }
        else if (threat === 0)      good.push('Google: clean');
      } catch (e) { /* ignore */ }
    }

    score = Math.max(0, Math.min(100, score));
    var cls   = score >= 70 ? 's' : score >= 40 ? 'w' : 'd';
    var label = score >= 70 ? 'Low Risk' : score >= 40 ? 'Medium Risk' : 'High Risk';

    /* tags */
    var tags = good.map(function (t) { return '<span class="tt g">' + esc(t) + '</span>'; }).join('')
      + warn.map(function (t) { return '<span class="tt y">' + esc(t) + '</span>'; }).join('')
      + bad.map(function (t)  { return '<span class="tt r">' + esc(t) + '</span>'; }).join('');

    /* detail rows */
    var rows = [
      { k: 'Domain',     v: domain,    c: '' },
      { k: 'Protocol',   v: isHttps ? 'HTTPS' : 'HTTP', c: isHttps ? 'ok' : 'bad' },
      { k: 'SSL Grade',  v: sslGrade || (isHttps ? 'Present' : 'None'), c: sslGrade ? (sslGrade.charAt(0) === 'A' ? 'ok' : 'mid') : (isHttps ? '' : 'bad') },
      { k: 'Domain Age', v: domainAge !== null ? (domainAge < 365 ? domainAge + ' days' : Math.floor(domainAge / 365) + ' years') : 'Unavailable', c: domainAge !== null && domainAge < 30 ? 'bad' : '' },
      { k: 'Registrar',  v: registrar ? registrar.substring(0, 32) : 'Unavailable', c: '' },
      { k: 'Registered', v: regDate ? regDate.toISOString().split('T')[0] : 'Unavailable', c: '' }
    ];

    var rowsHTML = rows.map(function (r) {
      return '<div class="tr-row"><span class="k">' + esc(r.k) + '</span><span class="v ' + r.c + '">' + esc(r.v) + '</span></div>';
    }).join('');

    return '<div class="tr">'
      + '<div class="tr-score"><span class="tr-num ' + cls + '">' + score + '</span><span class="tr-lbl">' + label + '</span></div>'
      + '<div class="tr-bar"><div class="tr-fill ' + cls + '" style="width:' + score + '%"></div></div>'
      + '<div class="tr-tags">' + tags + '</div>'
      + '<div class="tr-rows">' + rowsHTML + '</div>'
      + '<p class="tr-src">Sources: RDAP \u00b7 SSL Labs \u00b7 Google Safe Browsing</p>'
      + '</div>';
  }

  /* ── XSS helper ── */
  function esc(s) {
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  /* ── event delegation (single listener, no inline handlers) ── */
  document.addEventListener('click', function (e) {
    /* toolbar icon */
    var ic = e.target.closest('[data-panel]');
    if (ic) { open(ic.getAttribute('data-panel')); return; }

    /* close button */
    if (e.target.closest('#pdx-close')) { close(); return; }

    /* backdrop */
    if (e.target === backdrop) { close(); return; }

    /* scan button */
    if (e.target.id === 'pdx-scan') { scan(); return; }
  });

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') { close(); return; }
    if (e.key === 'Enter' && e.target.id === 'pdx-ti') { scan(); }
  });

}());
