<?php
/**
 * Plugin Name:  PaxDesign Floating Toolbar
 * Plugin URI:   https://paxdesign.io
 * Description:  Minimal floating utility toolbar with Trust Checker and service panels. Works immediately after activation.
 * Version:      1.0.0
 * Author:       PaxDesign
 * License:      GPL-2.0-or-later
 * Text Domain:  paxdesign-toolbar
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'PDX_VER', '1.0.0' );
define( 'PDX_DIR', plugin_dir_path( __FILE__ ) );
define( 'PDX_URL', plugin_dir_url( __FILE__ ) );

/* enqueue */
add_action( 'wp_enqueue_scripts', 'pdx_enqueue' );
function pdx_enqueue() {
    wp_enqueue_style(  'pdx-toolbar', PDX_URL . 'assets/toolbar.css', array(), PDX_VER );
    wp_enqueue_script( 'pdx-toolbar', PDX_URL . 'assets/toolbar.js',  array(), PDX_VER, true );
    wp_localize_script( 'pdx-toolbar', 'PDX', array(
        'contact' => esc_url( pdx_contact_url() ),
    ) );
}

/* auto-resolve contact page */
function pdx_contact_url() {
    $p = get_page_by_path( 'contact' );
    if ( $p ) return get_permalink( $p->ID );
    $pages = get_pages( array( 'search' => 'contact', 'number' => 1 ) );
    if ( ! empty( $pages ) ) return get_permalink( $pages[0]->ID );
    return home_url( '/#contact' );
}

/* render toolbar */
add_action( 'wp_footer', 'pdx_render', 100 );
function pdx_render() { ?>
<div id="pdx-root">
  <nav id="pdx-bar">
    <button class="pdx-ic" data-panel="trust"      data-tip="Trust Check"       aria-label="Trust Check"><svg viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg></button>
    <span class="pdx-sep"></span>
    <button class="pdx-ic" data-panel="create"     data-tip="Create"            aria-label="Create"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg></button>
    <button class="pdx-ic" data-panel="personas"   data-tip="AI Personas"       aria-label="AI Personas"><svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="3.5"/><path d="M5 20c0-3.5 3.1-6 7-6s7 2.5 7 6"/></svg></button>
    <button class="pdx-ic" data-panel="automation" data-tip="Automation"        aria-label="Browser Automation"><svg viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><path d="M17.5 14v6M14.5 17h6"/></svg></button>
    <button class="pdx-ic" data-panel="osint"      data-tip="OSINT"             aria-label="OSINT Agents"><svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="6.5"/><path d="M20 20l-3.5-3.5"/></svg></button>
    <button class="pdx-ic" data-panel="connectors" data-tip="Connectors"        aria-label="Connectors"><svg viewBox="0 0 24 24"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg></button>
    <button class="pdx-ic" data-panel="builder"    data-tip="AI Builder"        aria-label="AI Builder"><svg viewBox="0 0 24 24"><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/></svg></button>
    <button class="pdx-ic" data-panel="pipeline"   data-tip="Agent Pipeline"    aria-label="Agent Pipeline"><svg viewBox="0 0 24 24"><circle cx="5" cy="12" r="2"/><circle cx="19" cy="5" r="2"/><circle cx="19" cy="19" r="2"/><path d="M7 12h4l4-5M7 12l4 1 4 4"/></svg></button>
  </nav>
  <div id="pdx-backdrop"></div>
  <aside id="pdx-panel" role="dialog" aria-modal="true">
    <div id="pdx-inner"></div>
  </aside>
</div>
<?php }
